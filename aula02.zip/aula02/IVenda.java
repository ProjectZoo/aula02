public interface IVenda {

    public abstract String venda(String marca, String modelo, String ano, String valor);
    public abstract String compra();
    public abstract String troca();
}
