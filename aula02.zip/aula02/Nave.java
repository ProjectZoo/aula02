public class Nave {
    
}
